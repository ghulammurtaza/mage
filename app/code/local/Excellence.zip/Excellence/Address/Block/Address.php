<?php
class Excellence_Address_Block_Address extends Mage_Core_Block_Template
{
}